# Portafolio Personal
# Datos personales

- Universidad: Univalle
- Nombre: Gadiel
- Semestre: Segundo
- Interes: Desarrollo Web, VideoJuegos, IA
- Contacto: apg2031807@est.univalle.edu